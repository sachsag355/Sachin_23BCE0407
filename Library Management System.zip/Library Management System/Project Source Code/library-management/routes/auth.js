    const express = require('express');
    const router = express.Router(); // Ensure this line is correct
    const User = require('../models/user');
    const jwt = require('jsonwebtoken');
    const { protect } = require('../middleware/authMiddleware');

    router.post('/register', async (req, res) => {
        console.log('Attempting to register user. Request Body:', req.body);
        const { name, email, password } = req.body;
        if (!name || !email || !password) { return res.status(400).json({ message: 'Please enter all required fields: name, email, and password.' }); }
        if (password.length < 6) { return res.status(400).json({ message: 'Password must be at least 6 characters long.' }); }
        try {
            let user = await User.findOne({ email });
            if (user) { console.log('Registration failed: User with this email already exists.'); return res.status(400).json({ message: 'User with this email already exists.' }); }
            user = new User({ name, email, password });
            await user.save();
            console.log('User registered successfully:', user.email);
            const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.status(201).json({ message: 'User registered successfully!', token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
        } catch (error) { console.error('Error during user registration:', error); if (error.code === 11000) { return res.status(400).json({ message: 'An account with this email already exists.' }); } res.status(500).json({ message: 'Server error during registration.', error: error.message }); }
    });

    router.post('/login', async (req, res) => {
        console.log('Attempting to log in user. Request Body:', req.body);
        const { email, password } = req.body;
        if (!email || !password) { return res.status(400).json({ message: 'Please enter both email and password.' }); }
        try {
            const user = await User.findOne({ email });
            if (!user) { console.log('Login failed: Invalid credentials (email not found).'); return res.status(400).json({ message: 'Invalid credentials.' }); }

            // THIS LOG MUST BE PRESENT
            console.log(`Found user ${user.email}. Attempting to match password.`);
            const isMatch = await user.matchPassword(password); // This calls the method with debug logs
            if (!isMatch) {
                console.log('Login failed: Invalid credentials (password mismatch).');
                return res.status(400).json({ message: 'Invalid credentials.' });
            }
            const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
            console.log('User logged in successfully. Token generated.');
            res.json({ message: 'Login successful!', token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
        } catch (error) { console.error('Error during user login:', error); res.status(500).json({ message: 'Server error during login.', error: error.message }); }
    });

    router.get('/profile', protect, async (req, res) => {
        try {
            const userProfile = await User.findById(req.user.id).select('-password').populate('borrowedBooks');
            if (!userProfile) { return res.status(404).json({ message: 'User profile not found.' }); }
            res.json({ message: 'User profile retrieved successfully.', user: userProfile });
        } catch (error) { console.error('Error fetching user profile:', error); res.status(500).json({ message: 'Server error fetching profile.', error: error.message }); }
    });

    module.exports = router;
    