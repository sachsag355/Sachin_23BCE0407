const express = require('express');
const router = express.Router();
const Book = require('../models/book');
const User = require('../models/user');
const { protect, authorizeRoles } = require('../middleware/authMiddleware');

router.get('/test', (req, res) => {
    console.log('books.js: GET /test route hit.');
    res.send('Books route working');
});

router.get('/', async (req, res) => {
    console.log('books.js: GET /books route hit.');
    try {
        const books = await Book.find({});
        res.json({ message: 'Books retrieved successfully!', books });
    } catch (error) {
        console.error('books.js: Error in GET /books route:', error);
        res.status(500).json({ message: 'Server error while fetching books.', error: error.message });
    }
});

router.post('/', protect, authorizeRoles('admin'), async (req, res) => {
    console.log('books.js: POST / route hit. Request Body:', req.body);
    try {
        const { title, author, isbn, publishedDate, genre, copies } = req.body;

        if (!title || !author || !isbn || !copies) {
            console.log('books.js: Missing required fields.');
            return res.status(400).json({ message: 'Please enter all required fields: title, author, isbn, copies' });
        }

        const existingBook = await Book.findOne({ isbn });
        if (existingBook) {
            return res.status(400).json({ message: 'A book with this ISBN already exists.' });
        }

        const newBook = new Book({
            title,
            author,
            isbn,
            publishedDate,
            genre,
            copies,
            availableCopies: copies
        });

        const savedBook = await newBook.save();
        console.log('books.js: Book saved successfully:', savedBook.title);
        res.status(201).json({ message: 'Book added successfully!', book: savedBook });
    } catch (error) {
        console.error('books.js: Error in POST / route:', error);
        if (error.code === 11000) {
            return res.status(400).json({ message: 'A book with this ISBN already exists.' });
        }
        res.status(500).json({ message: 'Server error while adding book.', error: error.message });
    }
});

router.delete('/:isbn', protect, authorizeRoles('admin'), async (req, res) => {
    console.log(`books.js: DELETE /${req.params.isbn} route hit.`);
    try {
        const { isbn } = req.params;

        const bookToDelete = await Book.findOne({ isbn });
        if (!bookToDelete) {
            return res.status(404).json({ message: 'Book not found.' });
        }

        const usersWithBook = await User.find({ borrowedBooks: bookToDelete._id });
        if (usersWithBook.length > 0) {
            return res.status(400).json({ message: 'Cannot delete book: it is currently borrowed by one or more users.' });
        }

        const result = await Book.deleteOne({ isbn });

        if (result.deletedCount === 0) {
            return res.status(404).json({ message: 'Book not found (after check).' });
        }

        console.log(`Book with ISBN ${isbn} deleted successfully.`);
        res.json({ message: 'Book deleted successfully!' });

    } catch (error) {
        console.error('books.js: Error in DELETE /:isbn route:', error);
        res.status(500).json({ message: 'Server error while deleting book.', error: error.message });
    }
});

router.post('/borrow', protect, authorizeRoles('member'), async (req, res) => {
    console.log(`books.js: POST /borrow route hit. User: ${req.user.email}, Request Body:`, req.body);
    const { isbn } = req.body;
    const userId = req.user.id;

    if (!isbn) {
        return res.status(400).json({ message: 'Please provide the ISBN of the book to borrow.' });
    }

    try {
        const book = await Book.findOne({ isbn });
        console.log('books.js: Found book object (borrow):', book ? book.title : 'NOT FOUND'); // DEBUG LOG
        if (!book) {
            return res.status(404).json({ message: 'Book not found.' });
        }

        if (book.availableCopies <= 0) {
            return res.status(400).json({ message: 'No available copies of this book.' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        if (user.borrowedBooks.includes(book._id)) {
             return res.status(400).json({ message: 'You have already borrowed this book.' });
        }

        book.availableCopies -= 1;
        await book.save();

        user.borrowedBooks.push(book._id);
        await user.save();

        console.log('books.js: Sending borrow success message with title:', book.title); // DEBUG LOG
        res.status(200).json({ message: `Book "${book.title}" borrowed successfully!` });

    } catch (error) {
        console.error('books.js: Error in POST /borrow route:', error);
        res.status(500).json({ message: 'Server error while borrowing book.', error: error.message });
    }
});


router.post('/return', protect, authorizeRoles('member'), async (req, res) => {
    console.log(`books.js: POST /return route hit. User: ${req.user.email}, Request Body:`, req.body);
    const { isbn } = req.body;
    const userId = req.user.id;

    if (!isbn) {
        return res.status(400).json({ message: 'Please provide the ISBN of the book to return.' });
    }

    try {
        const book = await Book.findOne({ isbn });
        console.log('books.js: Found book object (return):', book ? book.title : 'NOT FOUND'); // DEBUG LOG
        if (!book) {
            return res.status(404).json({ message: 'Book not found.' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        const bookIndex = user.borrowedBooks.findIndex(
            (borrowedBookId) => borrowedBookId.toString() === book._id.toString()
        );

        if (bookIndex === -1) {
            return res.status(400).json({ message: 'You have not borrowed this book.' });
        }

        book.availableCopies += 1;
        await book.save();

        user.borrowedBooks.splice(bookIndex, 1);
        await user.save();

        console.log('books.js: Sending return success message with title:', book.title); // DEBUG LOG
        res.status(200).json({ message: `Book "${book.title}" returned successfully!` });

    } catch (error) {
        console.error('books.js: Error in POST /return route:', error);
        res.status(500).json({ message: 'Server error while returning book.', error: error.message });
    }
});

module.exports = router;
