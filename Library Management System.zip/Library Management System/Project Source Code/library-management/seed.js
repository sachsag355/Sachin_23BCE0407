const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/user');
const Book = require('./models/book');
const bcrypt = require('bcryptjs');

dotenv.config();

const MONGO_URI = process.env.MONGO_URI;

const usersData = [
    {
        name: 'Admin Library',
        email: 'admin@library.com',
        password: 'adminpassword', // We are using 'adminpassword' for consistency
        role: 'admin'
    },
    {
        name: 'Emily Student',
        email: 'emily@library.com',
        password: 'studentpassword',
        role: 'member'
    },
    {
        name: 'John Student',
        email: 'john@library.com',
        password: 'studentpassword',
        role: 'member'
    },
    {
        name: 'Jane Member',
        email: 'jane@library.com',
        password: 'memberpassword',
        role: 'member'
    }
];

const booksData = [
    {
        title: 'The Great Gatsby',
        author: 'F. Scott Fitzgerald',
        isbn: '978-0743273565',
        publishedDate: '1925-04-10',
        genre: 'Classic, Fiction',
        copies: 5,
        availableCopies: 5
    },
    {
        title: '1984',
        author: 'George Orwell',
        isbn: '978-0451524935',
        publishedDate: '1949-06-08',
        genre: 'Dystopian, Science Fiction',
        copies: 3,
        availableCopies: 3
    },
    {
        title: 'To Kill a Mockingbird',
        author: 'Harper Lee',
        isbn: '978-0061120084',
        publishedDate: '1960-07-11',
        genre: 'Classic, Southern Gothic',
        copies: 4,
        availableCopies: 4
    },
    {
        title: 'The Hobbit',
        author: 'J.R.R. Tolkien',
        isbn: '978-0345339683',
        publishedDate: '1937-09-21',
        genre: 'Fantasy',
        copies: 6,
        availableCopies: 6
    },
    {
        title: 'Pride and Prejudice',
        author: 'Jane Austen',
        isbn: '978-0141439518',
        publishedDate: '1813-01-28',
        genre: 'Romance, Classic',
        copies: 2,
        availableCopies: 2
    },
    {
        title: 'Dune',
        author: 'Frank Herbert',
        isbn: '978-0441172719',
        publishedDate: '1965-08-01',
        genre: 'Science Fiction',
        copies: 3,
        availableCopies: 3
    },
    {
        title: 'The Catcher in the Rye',
        author: 'J.D. Salinger',
        isbn: '978-0316769174',
        publishedDate: '1951-07-16',
        genre: 'Coming-of-Age, Fiction',
        copies: 4,
        availableCopies: 4
    }
];

const seedDB = async () => {
    try {
        await mongoose.connect(MONGO_URI);
        console.log('✅ MongoDB Connected for Seeding');

        console.log('Clearing existing users and books...');
        await User.deleteMany({});
        await Book.deleteMany({});
        console.log('Existing data cleared.');

        console.log('Seeding books...');
        const createdBooks = await Book.insertMany(booksData.map(book => ({ ...book, availableCopies: book.copies })));
        console.log(`Seeded ${createdBooks.length} books.`);

        console.log('Seeding users...');
        for (const userData of usersData) {
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(userData.password, salt);
            userData.password = hashedPassword;
            
            // <<<<<<<<<<<<<<<< THIS IS THE MISSING LINE, ADD IT HERE >>>>>>>>>>>>>>>>>
            console.log(`Seed: User ${userData.email} generated HASH: ${hashedPassword}`);

            let user = new User(userData);

            if (user.email === 'emily@library.com') {
                const gatsby = createdBooks.find(b => b.isbn === '978-0743273565');
                const book1984 = createdBooks.find(b => b.isbn === '978-0451524935');
                if (gatsby) {
                    user.borrowedBooks.push(gatsby._id);
                    gatsby.availableCopies -= 1;
                    await gatsby.save();
                }
                if (book1984) {
                    user.borrowedBooks.push(book1984._id);
                    book1984.availableCopies -= 1;
                    await book1984.save();
                }
            } else if (user.email === 'john@library.com') {
                const hobbit = createdBooks.find(b => b.isbn === '978-0345339683');
                if (hobbit) {
                    user.borrowedBooks.push(hobbit._id);
                    hobbit.availableCopies -= 1;
                    await hobbit.save();
                }
            }
            await user.save();
        }
        console.log(`Seeded ${usersData.length} users.`);
        console.log('Database seeding complete!');

    } catch (err) {
        console.error('❌ Database Seeding Error:', err);
        process.exit(1);
    } finally {
        if (mongoose.connection.readyState === 1) {
            await mongoose.connection.close();
            console.log('MongoDB connection closed.');
        }
    }
};

seedDB();
