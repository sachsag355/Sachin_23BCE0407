const jwt = require('jsonwebtoken'); // Import jsonwebtoken for token verification
const User = require('../models/user'); // Import the User model

// Middleware function to protect routes
const protect = async (req, res, next) => {
    let token;

    // Check if the Authorization header exists and starts with 'Bearer'
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            // Extract the token from the header
            token = req.headers.authorization.split(' ')[1];

            // Verify the token using the JWT_SECRET from environment variables
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            // Find the user by ID from the token, excluding the password field
            // .select('-password') prevents sending the hashed password back
            req.user = await User.findById(decoded.id).select('-password');

            // Attach user role to the request for authorization checks later
            req.userRole = decoded.role;

            next(); // Proceed to the next middleware or route handler

        } catch (error) {
            console.error('Auth middleware error:', error.message);
            // If token is invalid or expired
            return res.status(401).json({ message: 'Not authorized, token failed.' });
        }
    }

    // If no token is provided
    if (!token) {
        return res.status(401).json({ message: 'Not authorized, no token.' });
    }
};

// Middleware function for role-based authorization (example for admin)
const authorizeRoles = (...roles) => { // Takes a list of roles, e.g., authorizeRoles('admin', 'manager')
    return (req, res, next) => {
        // Check if the user's role is included in the allowed roles
        if (!roles.includes(req.userRole)) {
            return res.status(403).json({ message: `User role '${req.userRole}' is not authorized to access this route.` });
        }
        next(); // User is authorized, proceed
    };
};

module.exports = { protect, authorizeRoles };
