``
function checkLoginState() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    const currentPage = window.location.pathname.split('/').pop();

    const publicPages = ['welcome.html', 'login.html', 'register.html', ''];

    if (!token || !user) {
        if (!publicPages.includes(currentPage)) {
            if (currentPage.includes('add-book.html') || currentPage.includes('delete-book.html') || currentPage.includes('issue-book.html') || currentPage.includes('return-book.html') || currentPage.includes('view-books.html') || currentPage.includes('student-profile.html') || currentPage.includes('admin-dashboard.html') || currentPage.includes('student-dashboard.html')) {
                 console.log(`No token found. Redirecting from ${currentPage} to login.`);
                 window.location.href = 'login.html';
            }
        }
    } else {
        const userData = JSON.parse(user);

        if (userData.role === 'admin' && ['student-dashboard.html', 'student-profile.html', 'view-books.html', 'issue-book.html', 'return-book.html'].includes(currentPage)) {
            console.log('Admin accessing student page. Redirecting to admin dashboard.');
            window.location.href = 'admin-dashboard.html';
        } else if (userData.role === 'member' && ['admin-dashboard.html', 'add-book.html', 'delete-book.html'].includes(currentPage)) {
            console.log('Member accessing admin page. Redirecting to student dashboard.');
            window.location.href = 'student-dashboard.html';
        }
    }
}
checkLoginState();


function displayMessage(elementId, message, type = 'error') {
    const messageElement = document.getElementById(elementId);
    if (messageElement) {
        messageElement.textContent = message;
        messageElement.className = '';
        if (type && type !== '') {
            messageElement.classList.add(type);
        }
    }
}

const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        displayMessage('message', '', '');

        try {
            const res = await fetch('/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });

            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Registration successful!', 'success');
                registerForm.reset();
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 1500);
            } else {
                displayMessage('message', data.message || 'Registration failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Error during registration fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}

const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        displayMessage('message', '', '');

        try {
            const res = await fetch('/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Login successful!', 'success');
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));

                if (data.user && data.user.role === 'admin') {
                    window.location.href = 'admin-dashboard.html';
                } else {
                    window.location.href = 'student-dashboard.html';
                }
            } else {
                displayMessage('message', data.message || 'Login failed. Please check your credentials.', 'error');
            }
        } catch (error) {
            console.error('Error during login fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}

const logoutButton = document.getElementById('logoutButton');
if (logoutButton) {
    logoutButton.addEventListener('click', () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'login.html';
    });
}

const addBookForm = document.getElementById('addBookForm');
if (addBookForm) {
    addBookForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const title = document.getElementById('title').value;
        const author = document.getElementById('author').value;
        const isbn = document.getElementById('isbn').value;
        const copies = document.getElementById('copies').value;
        const publishedDate = document.getElementById('publishedDate').value;
        const genre = document.getElementById('genre').value;

        displayMessage('message', '', '');

        if (!title || !author || !isbn || !copies) {
            displayMessage('message', 'Please fill in all required fields (Title, Author, ISBN, Copies).', 'error');
            return;
        }
        if (isNaN(copies) || parseInt(copies) < 1) {
            displayMessage('message', 'Copies must be a positive number.', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                displayMessage('message', 'You must be logged in to add books.', 'error');
                setTimeout(() => window.location.href = 'login.html', 1500);
                return;
            }

            const res = await fetch('/books', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    title,
                    author,
                    isbn,
                    copies: parseInt(copies),
                    publishedDate: publishedDate || undefined,
                    genre: genre || undefined
                })
            });

            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Book added successfully!', 'success');
                addBookForm.reset();
            } else {
                displayMessage('message', data.message || 'Failed to add book.', 'error');
                if (res.status === 401 || res.status === 403) {
                    displayMessage('message', 'Session expired or unauthorized. Please log in again.', 'error');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                }
            }
        } catch (error) {
            console.error('Error during add book fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}

const deleteBookForm = document.getElementById('deleteBookForm');
if (deleteBookForm) {
    deleteBookForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const isbn = document.getElementById('isbn').value;

        displayMessage('message', '', '');

        if (!isbn) {
            displayMessage('message', 'Please enter the ISBN of the book to delete.', 'error');
            return;
        }

        if (!window.confirm('Are you sure you want to delete this book?')) {
            return;
        }

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                displayMessage('message', 'You must be logged in to delete books.', 'error');
                setTimeout(() => window.location.href = 'login.html', 1500);
                return;
            }

            const res = await fetch(`/books/${isbn}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Book deleted successfully!', 'success');
                deleteBookForm.reset();
            } else {
                displayMessage('message', data.message || 'Failed to delete book.', 'error');
                if (res.status === 401 || res.status === 403) {
                    displayMessage('message', 'Session expired or unauthorized. Please log in again.', 'error');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                }
            }
        } catch (error) {
            console.error('Error during delete book fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}

const booksListElement = document.getElementById('booksList');
if (booksListElement) {
    async function fetchAllBooks() {
        try {
            const res = await fetch('/books');
            const data = await res.json();

            if (res.ok) {
                if (data.books && data.books.length > 0) {
                    booksListElement.innerHTML = '';
                    data.books.forEach(book => {
                        const bookItem = document.createElement('li');
                        bookItem.classList.add('book-item');
                        bookItem.innerHTML = `
                            <h3>${book.title}</h3>
                            <p><strong>Author:</strong> ${book.author}</p>
                            <p><strong>ISBN:</strong> ${book.isbn}</p>
                            <p><strong>Genre:</strong> ${book.genre || 'N/A'}</p>
                            <p><strong>Published:</strong> ${book.publishedDate ? new Date(book.publishedDate).toLocaleDateString() : 'N/A'}</p>
                            <p class="${book.availableCopies > 0 ? 'copies-available' : 'copies-unavailable'}">
                                Available Copies: ${book.availableCopies} / ${book.copies}
                            </p>
                        `;
                        booksListElement.appendChild(bookItem);
                    });
                } else {
                    booksListElement.innerHTML = '<li>No books found in the library.</li>';
                }
            } else {
                displayMessage('message', data.message || 'Failed to load books.', 'error');
            }
        } catch (error) {
            console.error('Error fetching all books:', error);
            displayMessage('message', 'Network error loading books. Please try again later.', 'error');
        }
    }
    fetchAllBooks();
}

const profileNameElement = document.getElementById('profileName');
if (profileNameElement) {
    const profileEmailElement = document.getElementById('profileEmail');
    const profileRoleElement = document.getElementById('profileRole');
    const borrowedBooksListElement = document.getElementById('borrowedBooksList');

    async function fetchUserProfile() {
        const token = localStorage.getItem('token');
        if (!token) {
            displayMessage('message', 'You are not logged in. Redirecting to login.', 'error');
            setTimeout(() => window.location.href = 'login.html', 1500);
            return;
        }

        try {
            const res = await fetch('/auth/profile', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const data = await res.json();

            if (res.ok) {
                const user = data.user;
                profileNameElement.textContent = user.name || 'N/A';
                profileEmailElement.textContent = user.email;
                profileRoleElement.textContent = user.role;

                if (user.borrowedBooks && user.borrowedBooks.length > 0) {
                    borrowedBooksListElement.innerHTML = '';
                    user.borrowedBooks.forEach(book => {
                        const listItem = document.createElement('li');
                        listItem.innerHTML = `
                            <strong>${book.title}</strong> by <span>${book.author}</span><br>
                            <span class="isbn">ISBN: ${book.isbn}</span>
                        `;
                        borrowedBooksListElement.appendChild(listItem);
                    });
                } else {
                    borrowedBooksListElement.innerHTML = '<li>No books borrowed yet.</li>';
                }
            } else {
                displayMessage('message', data.message || 'Failed to load profile data.', 'error');
                if (res.status === 401 || res.status === 403) {
                    displayMessage('message', 'Session expired or unauthorized. Please log in again.', 'error');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                }
            }
        } catch (error) {
            console.error('Error fetching user profile:', error);
            displayMessage('message', 'Network error loading profile. Please try again later.', 'error');
        }
    }

    fetchUserProfile();
}

const issueBookForm = document.getElementById('issueBookForm');
if (issueBookForm) {
    issueBookForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const isbn = document.getElementById('isbn').value;
        displayMessage('message', '', '');

        if (!isbn) {
            displayMessage('message', 'Please enter the ISBN of the book to issue.', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                displayMessage('message', 'You must be logged in to issue books.', 'error');
                setTimeout(() => window.location.href = 'login.html', 1500);
                return;
            }

            const res = await fetch('/books/borrow', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ isbn })
            });
            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Book issued successfully!', 'success');
                issueBookForm.reset();
            } else {
                displayMessage('message', data.message || 'Failed to issue book.', 'error');
                if (res.status === 401 || res.status === 403) {
                    displayMessage('message', 'Session expired or unauthorized. Please log in again.', 'error');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                }
            }
        }
        catch (error) {
            console.error('Error during issue book fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}

const returnBookForm = document.getElementById('returnBookForm');
if (returnBookForm) {
    returnBookForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const isbn = document.getElementById('isbn').value;
        displayMessage('message', '', '');

        if (!isbn) {
            displayMessage('message', 'Please enter the ISBN of the book to return.', 'error');
            return;
        }

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                displayMessage('message', 'You must be logged in to return books.', 'error');
                setTimeout(() => window.location.href = 'login.html', 1500);
                return;
            }

            const res = await fetch('/books/return', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ isbn })
            });
            const data = await res.json();

            if (res.ok) {
                displayMessage('message', data.message || 'Book returned successfully!', 'success');
                returnBookForm.reset();
            } else {
                displayMessage('message', data.message || 'Failed to return book.', 'error');
                if (res.status === 401 || res.status === 403) {
                    displayMessage('message', 'Session expired or unauthorized. Please log in again.', 'error');
                    setTimeout(() => window.location.href = 'login.html', 2000);
                }
            }
        } catch (error) {
            console.error('Error during return book fetch:', error);
            displayMessage('message', 'Network error. Please try again later.', 'error');
        }
    });
}
